This is a pre alpha release, everything seems to work as I expect it to  when I've been trying it, 
however there is still information I need to decode and something I've not worked out yet could cause problems.
I have added an errors collection that gives details of any block that gave an error while decoding.

Run the RunMe.bat to register the ActiveX Control, You will then be able to use it in VBScript,
For .net users you should be able to add a reference to the DLL as a .net object.
A demo script has been provided that dumps a fleet report to fleets.txt in the current directory.

There are lots of properties available so I will only be listing them rather than explaining what they are.
Anything with [] aster it is a collection, anything with () after it is a function.

StarsPlayerEditor
  Load(filename)
  PlanetCount
  PlayerCount
  GameName
  TurnNo
  Planets[] - Currently only your occupied planets
  Scores[]
  Wormholes[]
  Minefields[]
  MTs[]
  Fleets[]
  EnemyFleets[]
  ShipDesigns[]
  StarbaseDesigns[]
  Errors[]

Planet
  Artefact
  Boranium
  BoraniumConcentration
  Defenses
  EstimatedPopulation
  Factories
  Germanium
  GermaniumConcentration
  Gravity
  Homeworld
  Ironium
  IroniumConcentration
  MDSpeed
  MDTarget
  Mines
  NameID
  OwnerID
  PlanetData - Byte array containing the raw data block
  PlanetID
  Population
  Radiation
  Scanner
  StarbaseDamage
  StarbaseSlotID
  StarbaseUnknown1 - Bottom 5 bits are part of stabase damage, top 3 are unnown
  Unknown1
  Unknown2 - Lowest bit is scanner, rest unknown
  Unknown3
  X
  Y

Wormhole
  WormholeID
  TargetWormholeID
  X
  Y
  Stability
  Unknown

Salvage - Includes packets
  SalvageID
  OwnerID
  X
  Y
  TargetPlanetID - 1023 if salvage
  WarpSpeed
  WarpOverMDLimit
  Ironium
  Boranium
  Germanium
  Unknown

Score
  PlayerID
  Year
  Rank
  Score
  Resources
  Planets
  Starbases
  UnarmedShips
  EscortShips
  CapitalShips
  TechLevels

Minefields
  MineFieldID
  PlayerID
  X
  Y
  Minecount
  Unknown1
  Unknown2 - Lowest 2 bits are type
  Unknown3 - probably who can see it, ie no longer cloaked to them
  ExplodingMinefield
  Type

MTs
  MTID
  X
  Y
  DestX
  DestY
  Speed
  Unknown

Fleet
  Ships[]
  FleetID
  OwnerID
  X
  Y
  Ironium
  Boranium
  Germanium
  Fuel
  BattlePlan
  Unknown

Ships
  DesignID
  ShipCount
  Damage

Design
  Slots[]
  DesignID
  Starbase
  OwnerID - Currently not set as I have yet to find it
  Name
  ShipHullID

Slot
  SlotID
  ItemCategory - This is an enum of TechCategories below
  ItemID
  Count

TechCategories - Enum
  Empty=0
  Engine=1
  Scanners=2
  Shields=4
  Armor=8
  BeamWeapon=16
  Torpedo=32
  Bomb=64
  MiningRobot=128
  MineLayer=256
  Orbital=512
  Planetary=1024 - Assumed since it appears to be the only missing one
  Electrical=2048
  Mechanical=4096
  