Stretched Universe - Release Notes

Stretched universe is a command line utility that rescales (stretches or squashes)
a universe for the Stars! game.

Parameters:
stretch <filename> <oldsize> <newsize>

<filename> = the file name of the xy file you want to modify
<oldsize> = the current size of the universe (0 = tiny, 1 = small..4 = huge)
<newsize> = the new size of the universe (same scale, but can go up to 7 and stars will still generate turns)

Compatibility:
This software has been tested with windows NT 4.0 and stars! 2.7i.  It probably works with NT3.51,
Windows 95 and 98; stars! 2.6i.  If you get a message about a missing DLL, try www.microsoft.com.
It will not run on windows 3.1, sorry - If anyone desperately wants to do a port, let me know.  I
use memory map files, so its not just a simple recompile but not a difficult port either.

Bug List:

Stat Seve Description
 P    1   Since only the XY file is modified, game objects such as ships appear to retain their
          original deep space location after the program is run.  If the ship is at a planet, it
          will actually move from the planet although the blue waypoint lines go from deep space.
          Shift click on the planet you are at will make the ship be properly at the planet without
		  fuel usage next turn.
          This bug only affects objects already in the universe - so I don't recommend using the
          program except on turn 2400
 P    2   Ships affected by the above bug won't be able to use stargates if the gate is out of range
          of the old position
 P    2   JOaT races have initial info on planets which were in range of their penscan scouts before
          the rescale - this is free info on a couple of planets if you are expanding the universe,
		  or info you don't get until turn 2 in the case of a contracted universe
 L    3   Stretched universe doesn't work on files created with Genesis, as they don't have a proper
          footer (2 bytes shorter than normal xy files).
 L    0   Stretched universe doesn't update the system timestamp on files it modifies

Explanation of Bug codes:
Statuses - P = permanent (stars uses information outside the xy file so I can't fix this).
           L = fix with a later release (non urgent)
           N = fix with the next release (urgent)
Severity - 0 = display or cosmetic outside of stars
           1 = display or cosmetic inside of stars
           2 = affects gameplay
           3 = corrupts the XY file
           4 = corrupts other files! (none of these known thankfully)

Credits + Thanks:
Hilton Lange for decoding the file structure with starstat.
Matthias Dellaert for collabarations on the XY file format.
My playtesters.

Legal bit:
1. Copyright
  Copyright on Stretched Universe [this program] is held by Shane Kearns 
  (shane.kearns@dial.pipex.com)
2. Disclaimer
  You use this program entirely at your own risk.  If your hard drive looks sufficiently
  like an XY file to fool the program and you give it an argument of \\.\PhysicalDrive0,
  you will trash your data - ditto if you run it on your business critical database.
3. Another Disclaimer
  This program isn't supported or endorsed by the authors of stars! or their publishers.
  Please don't bug them if stars crashes with modified data files (unless you can replicate
  the problem with untouched files).
  If you discover a bug in this program which is not in the bug list, report it to me.
  You should give details of which version of stretched universe and stars you use.
4. Distribution
  This program may be distributed for no charge on any web or ftp host that charges no fee
  for such downloads other than any incidental fee (e.g. internet access charges to local
  users).  If you are going to distribute this program like this, you may email me if you want
  to be kept up to date with new releases etc.
  Any distribution must include all files in the original distribution.
  This program may NOT be distributed for profit (e.g. CD-ROM) without my explicit permission
  or payment of a $100US royalty per copy >:).
5. Exceptions to 4
  If Jeff Johnson and Jeff McBride (the authors of Stars!) wish to include this program on a
  future release of the stars CD, they can.
6. Baroque legal documents
  Don't you just love reading through this stuff... Answers on a postcard to your favourite
  "cyber-promotions" (spam) company.  Make sure you send them an invoice for archival and
  proof-reading too.
