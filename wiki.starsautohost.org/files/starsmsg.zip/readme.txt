Stars! Message Reader v1.1
----------------------

(c) Thomas St�fe 1999





1) Introduction
2) Usage




1) Introduction

Do you know the strategy game Stars! ? 
Maybe you are even playing it? 
Are you as annoyed as I am every time you try to remember old player messages and wish the Stars! programmers had something done about it? 

Especially if you are playing more than one multiplayer Stars! game housekeeping your diplomatic post can be a real pain. If you begin to mix up races and send your blood enemy secret assault plans, it gets only worse.

The Stars! Message Reader is a help. It automatically scans Stars! and reads all messages. It stores them into an internal database, or you might save them as plain text file. You can easily read messages from previous turns and filter player messages.

The Stars! Message Reader works fine under Win95/Win98/NT4.0 with both the english and the german version of Stars!.





2) Usage

- Reading messages from Stars!:
To read messages from Stars!, click on the "Read From Stars!" button. You will be prompted for the Turn. Enter the Turn Number. Now the Messages will be read and displayed. They are stored automatically into an internal database. In addition, they are stored as text files.

(Note that as a default, only Player Messages are displayed.
To look at all messages, use the Filter "(All Messages)".)


- To read old messages: 
If necessary, open the game using the "Open Game" button. A list will be presented containing all games you have already turns stored for. Choose the game and read the messages of previous turns by using the "Prev"/ "Next" button beside the Turn number. Or choose your turn directly from a list of previous turns using the "Turn List" button.

- To view all (Player) messages of the last turns at once (Thread view):
Use the button "All Turns" beside the turn number. Now the messages of all turns are shown (only the player messages). Note that you can filter one race too to examine the correspondence you had with those aliens.

- To Filter messages: 
Various Filters can be applied upon the Messages. Use the Button "Filter" to choose your filter.



Enjoy this tool. Maybe you'll need it the next time I crush you on the galactic battlefield ;)


Thomas St�fe,
tstuefe@rhein-neckar.netsurf.de
www.micg.et.fh-stralsund.de/~tstuefe