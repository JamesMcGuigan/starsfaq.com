
** The Packet Flinger Calculator, version 1.0 **

The purpose of this program is to calculate optimal packet size & speeds for Stars! 2.6i.

It should run on any 32 bit ms-windows (NT, 95, etc).

To use it, simply extract the small executable, and run it.
Extracting right onto the desktop would work, if nothing better.



When run, a simple screen is presented, with the following fields:

Source Information:
	Flinger Rating: 	(Required) Enter the rating of the flinger at the source planet.
	Packet Physics:		Check if source race is PP.
	Interstellar Traveler:	Check if source race is IST.
	Dual Flingers:		Check if the source planet has two packet flingers.

Destination Information:
	Distance to Target:	(Required) Distance in light years from source to target planet.
	Population:		(Required) Enter the current population of target planet.
	Flinger Rating: 	Enter the rating of the flinger at the target planet.
	Packet Physics:		Check if target race is PP.
	Interstellar Traveler:	Check if target race is IST.
	Dual Flingers:		Check if the target planet has two packet flingers.
	Defenses:		Enter the current value of planet defense coverage.

Impact Information:
	Overkill:		Enter desired overkill, to compensate for possible target growth, or
				inaccuracies in the initial population estimate.  Typically, 15% is a 
				good value.  Increase it if high population or defenses growth is 
				likely.  Decrease it if it is unlikely.
	Packet Size:		The size of the packet to create, in queue clicks.
	Packet Speed:		The speed to set your flinger to.
	Air Time:		(Display) Years the packet will be in space, vulnerable to intercept.
	Colonists Killed:	(Display) The number of colonists at target who die.
	Defenses Destroyed:	(Display) The minimum and maximum number of target defenses destroyed.
	Minerals Recovered:	(Display) Minerals which will remain upon the ground after impact.


Or, to phrase it another (simplified) way:
	Required Input:		Source Flinger Speed, Distance to Target, Population
	"Answer":		Packet Mass, Packet Speed

The two "answer" fields are the two pieces of information you need to launch an optimal packet.
The remaining fields are either optional input, or informational.


If desired, you can use the PFC to calculate the damage results for a non-optimal packet.
Simply enter data into the Packet Mass and/or Packet Speed fields.  This also works for calculating 
damage from an inbound packet.  Note that entering data into any other field besides packet mass or 
packet speed will re-calculate optimal packet characteristics.


Be aware that packet damage is not 100% guaranteed to destroy the world (thus, the PFC has no warranty).
In addition, note that due to roundoff and precision, the PFC is not intended to be 100% accurate in 
its results, and it can be off by a few percentage points (up to say 3%).  Testbedding has shown that
in general it is within 1%.

The following factors can also interfere:
	Target Population growth and/or defense building (in excess of overkill compensation).
	Target can build a better flinger base (and thus catch better than expected).
	Target player can steal minerals out of the packet with a freighter (possibly cloaked).
	Target player can research the relevant level in Energy to kick up his defense coverage.
	User can enter data incorrectly in the PFC, or in Stars!.

This program is shareware, redistribute as you see fit, as long as you keep this text file 
(unaltered) with it.


Revision History:
.90	Initial Version
.92	Changed label from "Flinger Speed" to "Flinger Rating".
	Made input validation less obnoxious (null strings no longer trigger validation error).
	Made Packet Size & Speed enterable fields.
	Fixed a minor bug in the decay calculations for long-range packets.
	Added Colonists Killed (both population and percentage) display field.
	Clear display on a "no damage possible" entry result (it beats crashing).
.93	Corrected error in damage calculations
	Added Max defenses destroyed display
1.0	Minor documentation changes, full release.

Considered Features list:
	Terraforming potential of packet (waiting on resolution of how thats calculated).
	Calculate defense values from #defenses and type.


In the event that you like this program, or find it useful, you may register it by giving $5 to a 
worthy charity of your choice.  Benefits of registration should be obvious...


Check for the most recent version at:	http://www.monmouth.com/~cspag/PFC.zip
Report bugs, or give feedback to: 	cspag@monmouth.com
