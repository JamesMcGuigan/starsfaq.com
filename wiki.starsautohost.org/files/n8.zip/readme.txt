n8 - Stars! Hosting Assistant
copyright 1998, redmoon software, inc.
http://welcome.to/stars!

beta release notes - May 8, 1998

version [1.10beta]
- modified format slightly
- added support for multiple games
- added ability to delete games

version [1.01beta]
- corrected issue with failure to save Message Text
- added tooltip help
- added readme.txt
- added second attachment capability (thanks, Brett!)

version [1.0beta]
- initial release