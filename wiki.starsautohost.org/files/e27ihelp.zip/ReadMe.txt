3-31-98

This zip file contains the following files
required to use the full text search version
of the Stars! help file:

stars!.hlp -- the actual help file. Place in
              the same directory as stars!.exe

These files may already be in place if you
are just updating a previous help file:


hyprfind.dll -- German   98,816 bytes
                English  99,856 bytes

                DLL required for the full text
                search. Place in your Windows
                system directory -- for example, 
                Win 3.x and 95 (c:\windows\system)
		NT (c:\winnt\system)



ctl3dv2.dll -- DLL required for the full text
               search. Place in your Windows
               system directory.
 
               * If you leave a copy of this dll 
                 in the same directory as the help
                 file, you may receive an irritating 
                 error message each time the help is
                 opened. Remove the copy of the dll
                 from the help directory to get rid
                 of the message.
