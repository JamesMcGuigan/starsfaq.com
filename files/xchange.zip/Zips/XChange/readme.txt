Stars TurnXChange V1.3   
--------------------------------------------------------------

I had no intention of distributing these files, but as several
people seem to have a interest in seeing how I was able to
setup a web server to automatic hosting I thought I'd throw
this in to the public domain.

There are several hardcoded path information in the files so you'll
have to change it to match your setup if you choose to use it

The Stars TurnXChange is setup to run under a windows95 or NT
webserver.

You'll need the following.

 HTTP server
 FTP server
 Perl

The files does the following things.

cgi-lib.pl  	Your basic form parsing library
debug.pl    	A debugging library I've created
stars_lib.pl 	A library for some common routines involving stars.
autohost.pl	The script you must run when you start up you machine
turnex.pl	The script that generates the HTML screen on the fly for your users

starsgames 	Directory where all the games are stored. NOTE: the  *.exd files are stored
		here which discribes each stars games for turnex.pl to read from.

stars.bat
staryear.bat  	Apprently the HTTP server has problems allowing PERl to make system
		calls that will directly run Windows programs such as Stars. These bat
		files bypass that restrction
-------------------------------------------------

A sample transaction.  You can't use HTTP server to directly send and recieve files,
because stars files are binary, and the HTTP server only knows how to deal with text
and will corrupt the files.  So we have the FTP server.  User FTP theirs
files up to the FTP server. Autohost.pl is running in the background
realizes there has been afile upload and moves that file from the FTP directory in to
the stars directory.  If all the files are in, it generates a turn and then copies
it all back to the FTP out directory.

When the user goes to the page, it calls turnex.pl which disiplays the current game
status and provides allthe correct links to the different pages.


Thomas Tong 

ttong@lynx.bc.ca


	    
	     