#!/usr/local/bin/perl
#################################################################
# SOURCEFILE:  stars_lib.pl
#
# ABSTRACT:    General purpose debuging functions.
# REVISIONS:   Oct 24 / 1996  - Created
##################################################################

###########################################################################
#  CONFIG
###########################################################################
require "E:/www/cgi-bin/debug.pl";
$gTIME = 0;  ## DO NOT USE ASSERT function

$gNO_TURN = 0;
$gGOT_TURN =1;

$gIN_DIR = "F:/in";
$gOUT_DIR = "F:/out";

$gSTARSGAME_DIR = "E:/starsgames";
################################################################
#  MODULE:              Reads the stars data file stuff.
#
#  PARAMETERS:          Game Name.
#  RETURNS:             Associated array of data.
################################################################

sub ReadStarsEXD{
        local ($game) = @_;
        local ($exd_file) = $gSTARSGAME_DIR . "/" . $game . "/" . "$game.exd";
        local (@fileData, %outData, $num, $i, @temp);

        open(INFILE,"$exd_file");
        @fileData = <INFILE>;
        close(INFILE);

        $num = @fileData;
        for ( $i=0; $i<$num; $i++ )
        {
            @temp = split (/=/, $fileData[$i]);
            $outData{$temp[0]} = $temp [1];
        }
        return %outData;
}

################################################################
#  MODULE:              GetDirectoryList
#
#  ABSTRACT:            Get the listing of a directory
#  PARAMETERS:          Full path to the directory
#  RETURNS:             A array listing the contents of the directory
#
#  REVISIONS:          June 28 / 1996  - Thomas Tong Created:
#                       Oct 8/1996 - Ashish C. Morzaria
#                                   Added test for $SLASH.
#                                   Function did not work with a slash coming in
#                       Oct 9/1996 - Ashish C. Morzaria
#                                   Program now exits if you give it a slash suffixed name (per Thomas)
#################################################################
sub GetDirectoryList{

        local($directory) = @_;
        local(@dirlist,$length, $i);

        ## Reading the directory
        opendir (DIR, $directory);
        while ($temp = readdir (DIR))
        {
            push ( @dirlist, $temp);
        }
        closedir (DIR);

        # There are no dots in the root directory.. but we kill the directories
        # so we just got files in the case  H: for the FTP directory.
        splice(@dirlist,0,2);
        return @dirlist;
}

###############################################################
#  MODULE:              CopyDirectory
#  ABSTRACT:            Copies a directory's files from destination to a target.
#                       If it has subdirectories they are not copied
#  PARAMETERS:          Full path to the directory
#  RETURNS:             number of items copied if successful, 0 if unsuccesful
#
#  REVISIONS:          Sept 25 / 1996  - Frank Chin Created:
#
#						Sept 25/1996 - Ashish Morzaria
#							Changed syntax (it works now)
#							Changed, added $files[$i] loop, $SLASH symbols
#							Added NumItems as a return value
#
#						Sept 26/1996 - Ashish Morzaria
#							Added mkdir and $permsForDirectory parameter
#                       Sept 28/1996 - Thomas Tong
#                           Function didn't copy binary files
#                       Oct 8/1996 - Ashish Morzaria
#                           As per Wayne, ignore file permissions. Set at 777 (Umask drops it to 755)
#                      Dec 17/96 (Thomas)
#                           Took out tree perms parameter
#################################################################
sub CopyDirectory{
    local($fromDirectory,$toDirectory, $pattern) = @_;
    local($numfiles,@files,$NumItems,$i);

	@files = &GetDirectoryList($fromDirectory);
    $numfiles = @files;
	$NumItems =0;

    for ($i=0; $i < $numfiles; $i++)
		{
        # if not a directory and matches our pattern copy it. If no pattern then copy all
        if  (  ((!-d "$fromDirectory/$files[$i]") && ($files[$i] =~/^$pattern$/i))
            || (!$pattern))
        {
			$NumItems++;
            open(INFILE,"$fromDirectory/$files[$i]");
            open(OUTFILE,">$toDirectory/$files[$i]");
            binmode(INFILE);
            binmode(OUTFILE);

            @data = <INFILE>;
            print OUTFILE (@data);

            close(INFILE);
            close(OUTFILE);
			}
		}
		return $NumItems;
}

###############################################################
#  MODULE:              DeleteDirectory
#  ABSTRACT:            Deletes a directory and all files within it.
#
#						If it has subdirectories they are left in there
#                       and the directory is not deleted
#  PARAMETERS:          Full path to the directory
#  RETURNS:             if successful, 0 if unsuccesful
#
#  REVISIONS:          Sept 20 / 1996  - Frank Chin Created:
#			           Oct 4th - Frank added UNIX part because it has extra slash
#								 Added pattern to delete stuff
#################################################################
sub DeleteDirectory{
   local($directory, $pattern) = @_;
   local($numfiles,@files,$i);

   @files = &GetDirectoryList($directory);
   $numfiles = @files;

   for ($i=0; $i < $numfiles; $i++)
   {
        #if the pattern matches the file to delete, or no pattern at all
        if (($files[$i] =~ /^$pattern$/i) || (!$pattern))
        {
            unlink ("$directory/$files[$i]");
		}
   }
   #for now not killing directory just contents
   #return(rmdir (

}
## NOTE:: Need this for "requires" to work! DON'T Remove
1;