#!/usr/local/bin/perl
#################################################################
# SOURCEFILE:  debug.pl
#
# ABSTRACT:    General purpose debuging functions.
# REVISIONS:   Oct 24 / 1996  - Created
##################################################################

################################################################
#  MODULE:      ASSERT
#  ABSTEACT:   Checks a condition, if the condition is not true
#              it halts the program and does a printout of the system
#              with various variables.
#              It also checks how long the program has been running and
#              halts it if it has been running for too long.  ie Infinite loop
#
#  PARAMETERS: The condition that you want to check. Ensure you DO NOT enclose it
#              in quotes, and the error string you want displaced with the check
#  REVISIONS:   Created: Nov 15/96 Thomas Tong
#################################################################
sub ASSERT {
    local($condition, $error) = @_;
    local(@keys, @values, $len, $i, $timeRunning);

    $timeRunning=time();
    $timeRunning-=$gTIME;

    ## Program has been running too long or the test condition is false
    if ( (!$condition) || ($timeRunning > $gMAXTIME))
    {
        ## Print out environment variables
        print"Content-type:text/html\n\n";
        print"<h2>Assertion Error</h2>\n";

        @values = caller();
        print"<b>Error: $error</b><br>";
        print"Package: $values[0]<br>\n";
        print"File: $values[1]<br>\n";
        print"At Line: $values[2]<br>\n";

        $timeRunning=time();
        $timeRunning-=$gTIME;
        print"Time running: $timeRunning seconds";
        if ($timeRunning > $gMAXTIME)
        {
            print"....<B>Infinite loop: Above max runing time of $gMAXTIME seconds</b>";
        }

        print "<h3>ALiVE Version: $gHIGH_VERSION".".$gLOW_VERSION</h3>\n";
        print"<h2>Server Environment Variables</h2>\n";
        print"<hr>\n";
        @keys = keys(%ENV);
        @values = values(%ENV);
        $len = @keys;
        for ( $i=0; $i< $len; $i++ )
        {
            print "$keys[$i] = $values[$i] <br>\n";
        }
        exit -1;
    }
}

################################################################
#  MODULE:     LOG
#  ABSTEACT:   Opens the debug file and appends an entry to it.
#              It only runs if the @gDEBUGFILES has been defined for
#              the file that has called it.
#
#  PARAMETERS: The string that you want logged in to the error file
#  REVISIONS:   Created: Nov 15/96 Thomas Tong
#################################################################
sub LOG{
    local($error) = @_;
    local(@beingLogged,  @debugAll, $timeRunning, @values, $temp);

        ## If no files, return rightaway. Slight performance.
        if (@gDEBUGFILES == "" )
        {
            return;
        }

        ## Check if the file who called us is being logged, all files being logged
        @values = caller();
        @beingLogged = grep ( /^$values[1]$/i, @gDEBUGFILES);
        @debugAll = grep ( /^all$/i, @gDEBUGFILES);
        if (@beingLogged || @debugAll)
        {
            ## Log data to disk
            open (LOGFILE, ">>$gLOGFILE");
            $temp .= "*************************************************************\n";
            $temp .= "$error\n";
            $temp .= "Package: $values[0]    File: $values[1]    Line: $values[2]\n";

            $timeRunning=time();
            $timeRunning-=$gTIME;
            $temp .= "Time running: $timeRunning seconds\n\n";
            print LOGFILE ("$temp");
            close (LOGFILE);
        }
}

################################################################
#  MODULE:     NEWLOG
#  ABSTEACT:   Deletes the old log file, starts a new one
#  PARAMETERS:
#  REVISIONS:   Created: Nov 15/96 Thomas Tong
#################################################################
sub NEWLOG{

    local($temp);
    unlink($gLOGFILE);
    open (LOGFILE, ">$gLOGFILE");
    $temp .= "*************************************************************\n";
    $temp .= "New log file started: Time:";
    $temp .= time();
    $temp .= "\n";
    print LOGFILE ("$temp");
}
## NOTE:: Need this for "requires" to work! DON'T Remove
1;