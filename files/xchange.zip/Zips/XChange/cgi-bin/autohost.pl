###########################################################################
#  Setting up debug
###########################################################################
print"Content-type: text/html\n\n";
require "E:/www/cgi-bin/stars_lib.pl";
$gLOGFILE = "E:/www/cgi-bin/debug.log";
#@gDEBUGFILES = ("all");
&NEWLOG;

while (1)
{
    ## Get list of available games
    @games = &GetDirectoryList($gSTARSGAME_DIR);

    $num_games = @games;
    for ($iCurrentGame=0; $iCurrentGame < $num_games; $iCurrentGame++)
    {
            ## Configure for this particular game
            %gameData = &ReadStarsEXD($games[$iCurrentGame]);
            $num_players = $gameData{NumPlayers};
            $gen_turns = $gameData{GenTurns};
            $game_name = $games[$iCurrentGame];
            @players_out = split(/\,/,$gameData{PlayersOut});

            $host_dir = $gSTARSGAME_DIR . "/" . $game_name;
            $game_out_dir = $gOUT_DIR . "/" . $game_name;

            ## Copy files for that particular game, and delete them
            &CopyDirectory($gIN_DIR, $host_dir, "$game_name\.x[0-9]+");
            &DeleteDirectory($gIN_DIR, "$game_name\.x[0-9]+");

            ## See if all turns are in.
            @data = &GetDirectoryList($host_dir);
            $flag = $gGOT_TURN;
            &LOG("HOST $host_dir\n @data");

            ## stars is 1 counting not 0.. increment by 1
            for ( $i=1; $i < ($num_players+1); $i++ )
            {
                $turn = "$game_name.x$i";
                @inList = grep ( /^$turn$/i, @data);
                if (!@inList)
                {
                    @NotInGame = grep ( /^$i$/, @players_out);
                    if (!@NotInGame)
                    {
                        $flag = $gNO_TURN;
                        &LOG ("Turn $turn is not available");
                    }
                }
            }
            &LOG ("TurnStatus: $flag");

            #All turns are in lets generate!
            if ( $flag == $gGOT_TURN )
            {
                for ( $i=0 ; $i<$gen_turns; $i++ )
                {
                    @command = ("d:\\alt\\stars.bat", "$game_name");
                    system(@command);
                }

                #Update the current year too
                @command = ("d:\\alt\\staryear.bat", "$game_name");
                system(@command);

                #We've just generated, now copy the .m files to the distribution directory
                &CopyDirectory($host_dir, $game_out_dir, "$game_name.m[0-9]+");
            }
    } ## Num games for loop
sleep(30);
}