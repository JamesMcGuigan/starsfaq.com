###########################################################################
#  Setting up debug
###########################################################################
print"Content-type: text/html\n\n";
require "E:/www/cgi-bin/stars_lib.pl";
require "E:/www/cgi-bin/cgi-lib.pl";
$gLOGFILE = "E:/www/cgi-bin/debug.log";
#@gDEBUGFILES = ("all");
##&NEWLOG;

###########################################################################
#  CONFIG
###########################################################################
&ReadParse(*in);

$game_name = $in{"game_name"};

if (!$game_name)
{
    print "You have not chose a valid game to choose.<br>";
    print "Try <a href=http://bowron.mc2.sfu.ca>here<a>";
    exit 1;
}

$host_dir = $gSTARSGAME_DIR . "/" . $game_name;

## read data file of game
%gameData = &ReadStarsEXD($game_name);
$num_players = $gameData{NumPlayers};
$full_name = $gameData{GameName};
## finout what turns are in and whose still inthe game
@PlayersOut = split(/\,/,$gameData{PlayersOut});
@PlayersIn = &GetDirectoryList($host_dir);

 ## read screen file and the basic player screen data
 open (SCREENFILE, "E:/www/turnexer.htm");
 @temp = <SCREENFILE>;
 $screenFile = join(" ",@temp);
 close (SCREENFILE);

 open (PLAYERFILE, "E:/www/player.htm");
 @temp = <PLAYERFILE>;
 $playerFile = join(" ",@temp);
 close (PLAYERFILE);

 ## stars is 1 counting not 0.. increment by 1
 for ( $i=1; $i < ($num_players+1); $i++ )
 {
        ## Temp data display data and get player info
        $turn = "$game_name.x$i";
        $temp = $playerFile;
        @playerData = split(/\,/,$gameData{"Player$i"});

        ## Replace in to list
        $temp =~ s/<RACE_NAME>/$playerData[2]/;
        $temp =~ s/<PLAYER_EMAIL>/$playerData[1]/;
        $temp =~ s/<PLAYER_NAME>/$playerData[0]/;
        $temp =~ s/<TURN_FILE>/$game_name\/$game_name.m$i/;
        $temp =~ s/<TURN_FILE_CAPTION>/$game_name.m$i/;

        ## Make those blinky lights depending if player is in or not.
        @InList = grep ( /^$turn$/i, @PlayersIn);
        if (!@InList)
        {
            @NotInGame = grep ( /^$i$/, @PlayersOut);
            if (@NotInGame)
            {
                $temp =~ s/<STATUS_GIF>/red-out.gif/;
            }
            else
            {
                $temp =~ s/<STATUS_GIF>/green-out.gif/;
            }

        }
        else
        {
            ## file uploaded.. but when?
            $FileName = $host_dir . "/" . $InList[0];
            @data = stat ($FileName);
            $time = $data[9];
            @timelist = gmtime($time);
            $string = "$timelist[4]/$timelist[3]/$timelist[5]  - $timelist[2]:$timelist[1]";

            $temp =~ s/<TIME_UL>/$string/;
            $temp =~ s/<STATUS_GIF>/green-in.gif/;
        }
       $allPlayerData .= $temp;
}

## What is current game year
$FileName = $host_dir . "/" . "$game_name.yr";
open (YEARFILE, $FileName);
$year = <YEARFILE>;
$screenFile =~ s/<CURRENT_YEAR>/$year/;

## Time When generated
$FileName = $host_dir . "/" . "$game_name.hst";
@data = stat ($FileName);
$time = $data[9];
@timelist = gmtime($time);
$string = "$timelist[4]/$timelist[3]/$timelist[5]  - $timelist[2]:$timelist[1]";
$screenFile =~ s/<TIME_GEN>/$string/;

## Current time
$time = time();
@timelist = gmtime($time);
$string = "$timelist[4]/$timelist[3]/$timelist[5]  - $timelist[2]:$timelist[1]";
$screenFile =~ s/<TIME_CURRENT>/$string/;

## List of games.
@games = &GetDirectoryList($gSTARSGAME_DIR);
@games = sort (@games);
$num_Games = @games;
undef ($string);
for ( $i=0; $i < $num_Games; $i++ )
{
    if ( $games[$i] eq  $game_name)
    {
        $string .= "<option selected>$games[$i]\n";
    }
    else
    {
        $string .= "<option>$games[$i]\n";
    }

}
$screenFile =~ s/<GAME_LIST>/$string/;


## Misc additions.
$screenFile =~ s/<DEFINITION_FILE>/$game_name\/$game_name.xy/;
$screenFile =~ s/<GAME_NAME>/$full_name/g;
$screenFile =~ s/<PLAYER_DATA>/$allPlayerData/;
print $screenFile;