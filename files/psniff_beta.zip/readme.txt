Welcome to the Stars! PlanetSniffer ReadMe.

Take a look at the Lunar State Industrial Institute (LSII) Homepage: http://lsii.virtualave.net/stars/index.html. The latest version of the PlanetSniffer can be found there. Send your emails to: PlanetSniffer@lsii.virtualave.net

How to install the Stars! PlanetSniffer:

1. Unpack the files to a directory of your choice. (you probably did this already ;)
2. Start PlanetSniffer
3. Open (Files | Open) "Noor.SPS"
4. Explore PlanetSniffer!
5. Report bugs and ideas to the above address.

If you want to use the PlanetSniffer with your own data, try (Files | New) to create your own race. The previous race will be erased and you can enter you own data, do not forget to SAVE it. To get the necessary .pXX files with the additional information add this to your Stars.ini: NewReports=1 ([Misc] section).

Send your ideas/problems to the above address and I'll try to fix/add it.

Thanx!

Have fun!