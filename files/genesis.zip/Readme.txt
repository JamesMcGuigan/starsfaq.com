Genesis beta 0.5

The FIRST Spiral galaxy creator for Stars!

I have little to say on the moment, just experiment a bit with it, make sure you read the disclaimer.
It's possible that Stars! will not take universes of all settings, if some universes don't work, just change the settings until they do.

Have fun.

INSTALLATION :

Just unzip it to your Stars! dir

DISCLAIMER :

Genesis is BETA software and thus subject to bugs and other child diseases.
It is recomended to save all your work before you run Genesis or even close all other programs.
The author shall not be held responsible for any damage caused by the running of this program.

If you do not agree to these terms, do NOT run Genesis.