Readme file for StarInfo.exe version 1.0

A freeware product of Price Technologies

This is a heavyweight windows 95 
implementation of the DOS starstat.exe
program by Hilton Lange.

Its size is due to two factors, first
it is programmed in VC++4.2 w/MFC, 
(Yes, I'm a lazy programmer) second 
it has been statically linked to the 
MFC core code rather than relying on 
the user having the correct dll.  As 
far as capabilities go, it is exactly 
the same as the starstat program 
except that it runs as a Win95 app 
and includes an Explorer type file 
browser.

********** BUGS ************************
One known bug, shared with starstat,
v2.6a files report a version no. 2.65.
Does anyone know why?

*** NOTES FOR DEVELOPERS & THE JEFFS ***
If anyone knows of how I can access a
CRC or checksum for an integrity check
let me know and I'll add it in the next
release.

***** BUG REPORTS **********************
Submit bug reports to me via e-mail
at blprice@twd.net.  Since this is
freeware I won't promise instant 
response but I will make an effort
to fix any major faults.

