/*
Copyright 2003 Elliott Kleinrock, Michael 'Wumpus' Zinn

This file is part of Map2XY

Map2XY is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

Map2XY is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FreeStars; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

The full GPL Copyright notice should be in the file GPL.txt

Contact:
Email Elliott at 9jm0tjj02@sneakemail.com
*/

#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>

#include <iostream>
#include <deque>

using namespace std;

const int headersize = 84;
const int footersize = 4;
const char * Map2XYname = "Map2XY";
const char * version = "(version 1.1)";

const int CHUNK = 64 * 1024;

struct position {
	unsigned int xoffset:10;
	unsigned int y:12;
	unsigned int nameid:10;
};

struct nameindex {
	nameindex(const char * n, int i) { strcpy(name, n); index = i; used = false; }
	char name[32];
	int index;
	bool used;
};

const char * nullify(char **p, char c)
{
	if (**p == '\0' || **p == '\n' || **p == '\r')
		return "";

	const char * ptr;
	ptr = *p;
	while (**p != c && **p != '\0' && **p != '\n' && **p != '\r')
		++*p;

	**p = '\0';
	++*p;
	return ptr;
}

int main(int argc, char* argv[])
{
	_fmode = _O_BINARY;
	if (argc != 2) {
		cout << "Usage: Map2XY <name>" << endl;
		cout << Map2XYname << " " << version << " reads a .map and a .xy and updates the .xy to the values in the .map file." << endl;
		return -1;
	}

	char *ptr;
	const char *ptr2;

	deque<nameindex> names;
	int namefile;
	namefile = open("planets.txt", _O_RDWR, _S_IREAD);
	if (namefile > 2) {
		char namedata[CHUNK];
		int namesize = read(namefile, namedata, CHUNK);
		if (namesize > 0 && namesize < CHUNK) {
			ptr = namedata;
			int index, pindex = -1;
			while (*ptr) {
				ptr2 = nullify(&ptr, '\t');	// index
				index = atol(ptr2);
				ptr2 = nullify(&ptr, '\t');	// Name
				while (*ptr && *ptr++ != '\n');	// skip the rest of the line
				if (index != pindex + 1) {
					cout << Map2XYname << " " << version << " error: " << "Invalid planet # " << index << " in planets.txt" << endl;
					return -1;
				}
				names.push_back(nameindex(ptr2, index));
				pindex = index;
			}
			if (pindex != 998) {
				cout << Map2XYname << " " << version << " error: " << "Invalid planets.txt, it needs exactly 999 entries , 0 - 998" << endl;
				return -1;
			}
		}
	}

	string mapname, xyname;
	int mapfile, xyfile;

	mapname = argv[1];
	mapname += ".map";
	xyname = argv[1];
	xyname += ".xy";

	xyfile = open(xyname.c_str(), _O_RDWR, _S_IREAD);
	if (xyfile <= 2) {
		cout << Map2XYname << " " << version << " error: " << "Cannot read " << xyname.c_str() << endl;
		return -1;
	}
	mapfile = open(mapname.c_str(), _O_RDONLY, _S_IREAD | _S_IWRITE);
	if (mapfile <= 2) {
		cout << Map2XYname << " " << version << " error: " << "Cannot read " << mapname.c_str() << endl;
		return -1;
	}

	char mapinfo[CHUNK];
	char oldxy[CHUNK];
	char newxy[CHUNK];
	int xysize, mapsize;

	mapsize = read(mapfile, mapinfo, CHUNK);
	if (mapsize <= 0) {
		cout << Map2XYname << " " << version << " error: " << "Cannot read " << mapname.c_str() << endl;
		return -1;
	} else if (mapsize >= CHUNK) {
		cout << Map2XYname << " " << version << " error: " << mapname.c_str() << " is too big" << endl;
		return -1;
	}
	mapinfo[mapsize] = '\0';
	close(mapfile);

	xysize = read(xyfile, oldxy, CHUNK);
	if (xysize <= 0) {
		cout << Map2XYname << " " << version << " error: " << "Cannot read " << xyname.c_str() << endl;
		return -1;
	} else if (xysize >= CHUNK) {
		cout << Map2XYname << " " << version << " error: " << xyname.c_str() << " is too big" << endl;
		return -1;
	}

	memcpy(newxy, oldxy, headersize);
	int pos = headersize;	// bit position
	int pnum;
	int oldpnum = 0;
	int newx;
	int lastnewx = 1000;
	int newy;

	position current;

	ptr = mapinfo;

	while (*ptr++ != '\n');	// skip the first line (header)

	while (*ptr) {
		memcpy(&current, &oldxy[pos], sizeof(position));

		ptr2 = nullify(&ptr, '\t');	// Planet Number
		pnum = atol(ptr2);
		if (pnum != oldpnum+1) {
			cout << Map2XYname << " " << version << " error: " << "Invalid planet # " << pnum << " in " << mapname.c_str() << endl;
			return -1;
		}

		oldpnum = pnum;

		ptr2 = nullify(&ptr, '\t');	// X
		newx = atol(ptr2);
		ptr2 = nullify(&ptr, '\t');	// Y
		newy = atol(ptr2);
		ptr2 = nullify(&ptr, '\t');	// Name
		while (*ptr && *ptr++ != '\n');	// skip the rest of the line

		if (newx < 1000 || newy < 1000) {
			cout << Map2XYname << " " << version << " error: " << "Invalid planet # " << pnum << " in " << mapname.c_str() << endl;
			return -1;
		}

		if (newx < lastnewx) {
			cout << Map2XYname << " " << version << " error: " << "Invalid planet # " << pnum << " in " << mapname.c_str() << endl;
			return -1;
		}

		for (int i = 0; i < names.size(); ++i) {
			char debug[32];
			strcpy(debug, names[i].name);
			if (strcmp(ptr2, names[i].name) == 0) {
				if (names[i].used) {
					cout << Map2XYname << " " << version << " error: " << "Duplicate planet name for planet # " << pnum << " in " << mapname.c_str() << endl;
					return -1;
				}
				current.nameid = names[i].index;
				names[i].used = true;
				break;
			}
		}

		if (i == names.size()) {
			cout << Map2XYname << " " << version << " error: " << "Invalid planet name for planet # " << pnum << " in " << mapname.c_str() << endl;
			return -1;
		}
		current.y = newy;
		current.xoffset = newx - lastnewx;
		lastnewx = newx;
		memcpy(&newxy[pos], &current, sizeof(position));
		pos += sizeof(position);
	}

	memcpy(&newxy[xysize-footersize], &oldxy[xysize-footersize], footersize);
//	assert(pos+footersize = xysize);
	lseek(xyfile, 0L, 0);	// go to start of file
	write(xyfile, newxy, xysize);	// write data

	close(xyfile);

	cout << Map2XYname << " " << version << " has updated " << xyname.c_str() << " with values from " << mapname.c_str() << endl;

	return 0;
}
