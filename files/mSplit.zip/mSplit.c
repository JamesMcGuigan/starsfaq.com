/* $Id: mSplit.c,v 1.1 2006/04/06 18:41:37 michaelz_wumpus Exp $
 *
 * mSplit.c: Splits the m-file specified on the command line into it's
 *            constitutent one-year parts, if it has more than one
 *            year in it.  
 *           Does not currently fix the header bit which indicates
 *            whether further years are present, since stars! doesn't
 *            seem to mind this.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#include "starsFile.h"
#define BLOCKTYPE_FILEHEADER 0x08  /* Excerpted from starsFile.h */

typedef enum {
	USAGE_DEFAULT,
	USAGE_NARGS,
	USAGE_OPEN_FILE,
	USAGE_BROKEN_FILE
} e_usage_reason;

void usage( e_usage_reason const reason, char const * const invocation_name );

typedef struct {
	unsigned int length : 10;
	unsigned int type   :  6;
} t_blockdesc;

int main( int argc, char ** argv )
{
	char *outFilename;
	int destNum;

	FILE *inFile, *outFile = NULL;
	t_blockdesc blockdesc;
	int ii;

	if( argc != 2 ) {
		usage( USAGE_NARGS, argv[0] );
		return( EXIT_FAILURE );
	}

	inFile = fopen( argv[1], "rb" );
	if( !inFile ) {
		usage( USAGE_OPEN_FILE, argv[0] );
		return( EXIT_FAILURE );
	}

	outFilename = malloc( strlen( argv[1] ) + 7 ); 
		/* 6 is enough for anyone :-P But seriously, for a
		 * pattern of <name>.##### (1 '.', 5 digits, 1 '\0')
		 * this is correct, and if there are more than 2^16
		 * turns (2^15 even?) then stars will almost certainly
		 * break down. */
	if( !outFilename ) {
		fprintf( stderr, "Memory allocation error!\n" );
		fclose( inFile );
		return( EXIT_FAILURE );
	}
	

	destNum = 0;

	while( fread( &blockdesc, 2, 1, inFile ) == 1 ) {
		if( blockdesc.type == BLOCKTYPE_FILEHEADER ) {
			if( outFile ) {
				fclose( outFile );
				outFile = NULL;
			}
			sprintf( outFilename, "%s.%05d", argv[1], destNum );

			printf( "Outputing turn #%d to '%s'.\n", destNum, outFilename );
			outFile = fopen( outFilename, "wb" );
			if( !outFile ) {
				fprintf( stderr, "Error opening output file '%s'.\n", outFilename ); 
				fclose( outFile );
				fclose( inFile );
				free( outFilename );
				return( EXIT_FAILURE );
			}

			/* Advance the destination counter for the
			 * *next* header. */
			destNum++;
		}

		if( !outFile ) {
			/* Only way to get here is if the first block
			 *  of the file is not a file header - so,
			 *  something really horribly wrong with the
			 *  input file. */
			usage( USAGE_BROKEN_FILE, argv[0] );
			fclose( inFile );
			free( outFilename );
			return( EXIT_FAILURE );
		}
		fwrite( &blockdesc, 2, 1, outFile );
		for( ii = 0; ii < blockdesc.length; ii++ ) {
			fputc( fgetc( inFile ), outFile );
		}
	}

	fclose( inFile );
	if( outFile ) {
		fclose( outFile );
	}
	free( outFilename );

	return( EXIT_SUCCESS );
}


void usage( e_usage_reason const reason, char const * const invocation_name )
{
	switch( reason ) {
		case USAGE_NARGS:
			fprintf( stderr, "ERROR: Incorrect number of arguments!\n\n" );
			break;
		case USAGE_OPEN_FILE:
			fprintf( stderr, "ERROR: Unable to open the M file for reading and writing.\n" );
			fprintf( stderr, "Please check that the file exists at the specified location and is both readable AND writable.\n\n" );
			break;
		case USAGE_BROKEN_FILE:
			fprintf( stderr, "ERROR: Expected header not found at start of file.\n" );
			fprintf( stderr, "Please check that the input file is really a Stars! M file.\n" );
			fprintf( stderr, "This tool may only work with recent (2.6jrc3-4) stars! files. \n\n" );
			break;
		default:
			break;
	}

	printf( "Usage: %s m_file\n", invocation_name );
	printf( "EG: %s test.m1\n", invocation_name );
	printf( "\tm_file: The name (and path, if not in the current directory)\n" );
	printf( "\t\tof the X file to alter.\n" );
}
