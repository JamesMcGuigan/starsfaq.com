Under XP:
   1) Find the planet you want to swap in Stars.
   2) Find a new name for that planet that's located in THE SAME list. (if it's not the same list an improper swap will occure, this is a limitation of: Stars XY files, and the amount of time I put into personally decoding them. If an improper swap occures just run the program again and enter the same numbers and it will restore the change.)
   3) If exists in the map already, simply drag and drop the xy file onto "StarSwap3 (Drag Drop XP Only).bat"  And enter the Planet ID's as provided by Stars. 
   3a) If name does not exist, Drag and drop the xy file onto "Starname (XP Drag Drop).bat" enter the star ID and then the "Name ID" which is listed in hex next to the name in the Star Names list.  And that's it. 

Under 98:
   Follow steps 1 and 2 from the XP version.. 
   3) From a dos box, use "Strswap2.bat" and enter the data in like this "StrSwap2.bat <XY name> <Planet ID1> <Planet ID2>" (Example: "StrSwap2.bat Test.xy 34 23" ) 
   3a) If name doesn't exist use "StarPoke.bat <XY> <Planet ID> <Name ID>" and that's that. 


-------------------
For those who are curious, what does each file do?:
 -Poke.exe                    -- Remote hex editor, takes commands like "Poke <file> <address> <value>" or "Poke <File> <Address>" if reading a value. Can output in Decimal(...), Hex (0x..), and Octal (0..), Only reads in decimal.

 -Star Names FOR STARS.txt    -- A comprehensive list I created which includes hex values for each name, (since there are 999 unique names and 1 byte to ID them, and 1 part of a byte to ID the list, I decided to only support the individual name ID's)

 -Starname (XP Drag Drop).bat -- Just a nicer way to use StarPoke.bat without having to open a dos box.

 -StarPoke.bat                -- My original "Stars Planet ID#" to "file address" converter (yes there were simpler ways to do it, but this was how I did it. ANd it works!)  (I used a formula to double check all 1000 values that are entered into that file.)

 -StrPoke2.bat                -- Same as StarPoke.bat except it takes decimal values for Name ID's instead of the original Hex values. Required for StarSwap2 and StarSwap3. (StarSwap the original was a manual interface to Starpoke, VERY annoying.. And you had to know the name IDs of both planets to use it.)

 -StarSwap3 (Drag Drop XP Only).bat -- A nice and tidy Star Name Swapping "program", Which will override any !.bat files you may have in the directory as it creates it's temp file.  Same goes for StrSwap2.

 -!Location.bat               -- Just a little something to make it easier when changing directories.  Keep a copy in either A) C drive's Root directory or B) someplace in the path... My files run this so they can find where they are located.  Enter the location of where you "Installed" this into that file, and make sure it's in the path somehow.

 -@changelog                  -- File StarSwap3 and StarSwap2 create, goes wherever "!Location" points, File contains a history of name alterations in this format: "<ID1> <ID2> <Name ID1> <Name ID2> <File>" You can disable it by remming out the line in StarSwap2 and 3 if you wish.



Batch File construction and all research onto how all this works done by "Captain Maim" (that's me)

Probably should keep this file with the rest of the other files..  


NOTE: Effect takes place instantly and only effects you..  Unless.. you get everyone to use your modified starmap.  THIS DOES NOT EFFECT: ANYTHING BUT NAMES.  And having more than 1 unique name in a map messes up "Ctrl F" find commands and maybe some other minor things.  Not recommended. (Lowest plaent ID will always be chosen and other planet(s) with same name won't get selected.)

If you have any questions contact me at Morthotos@dd-tech.org