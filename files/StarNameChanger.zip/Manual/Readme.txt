Simple use: 
1. Find the star you want to rename, read through the list provided find the name you want that is on the SAME LIST as the star you want to swap with.
2. Write down the Hex numbers of both stars as listed in the name's list. 
3. Go into stars, and use "Ctrl+f" to locate both stars and write down their ID#'s as displayed by stars. 
4. With a DOS prompt type something like: "StarSwap 13 2d 46 1f", result, star ID 13 Name ID 2d will be swapped with star 46 name ID 1f.

The effects take place immediately in game, regardless of year.  Only the names are changed.  The only effect this will have is if you exported maps you'll have to rexport them to fit with your new names. Other players should get your new XY file and then your set. 

This is the only way I could find the allow players to edit their HW names.  Like say you didn't like your HW called Slime, and you wanted to perhaps change it to Skunk for some reason.