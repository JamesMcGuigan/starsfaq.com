This is a pre alpha release, everything seems to work as I expect it to but I know from experience someone may try to do
something with it I would never even think of trying that could break it so I would highly recommend making a backup
of any files you edit with it first and then test them out to make sure it has done what you were expecting.

Run the RunMe.bat to register the ActiveX Control, You will then be able to use it in VBScript,
For .net users you should be able to add a reference to the DLL as a .net object.
A demo script has been provided that sets Iron to 1000000, Bora to 2000000, Germ to 3000000 and artefacts on all worlds
and pop to 1100000 on colonised worlds.
You will need to generate a turn to see the changes applied to a .m file.  

It is possible to load a .m file instead of a .hst file and modify that to show the same changes as you have made to a .hst
ie it should be possible to write a script that loads the .hst file and .m files into different objects,
makes changes to the .hst file and then looks through the other objects for planets that have the same ID and modify them.

At the moment each Planet object has the following properties available,

PlanetID - Readonly 
OwnerID, X, Y, NameID - Any changes are currently ignored, intend to have it working in next version (0=player 1, -1=not colonised)
Homeworld - The .hst file seems to ignore changes, the m files do see an effect but will lose it when the host generates
Terraformed - Readonly Boolean
Artefact - Boolean
Ironium, Boranium, Germanium & Population - Any 32 bit signed value
IroniumConcentratration, BoraniumConcentratration & GermaniumConcentratration - 0 to 255
Temperature, Gravity & Radiation - 0-100