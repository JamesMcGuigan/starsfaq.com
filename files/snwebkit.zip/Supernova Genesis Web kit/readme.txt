
Thank you for your interest in Stars! Supernova Genesis!

Enclosed are a variety of materials to help you to create your own custom Stars! Supernova Genesis Web site. We're giving everyone a chance to be creative, swap information, and have fun creating Web pages using materials from Stars! Supernova Genesis along with related art created for this kit.

Although we've provided entire Web page templates for your use, don't feel constrained to use these templates in part or in whole. They are here to provide a starting point. 

When you�ve got your site set up, drop us a line at Supernova@crisium.com. We'll add you to our Webpoints page.

There are 2 types of information in these documents, required and not required. The entire text from the 'legal.txt' file, as well as links to http://crisium.com and either http://www.empire-us.com or http://empire.co.uk must be present on your web site. The rest of the text is for your enjoyment and use. Please take this seriously, as there's nothing worse than having to get someone's Web site shut down for their incorrect use of material.

NOTE REGARDING SCREENSHOTS
Feel free to use any of the screenshots from our site, http://crisium.com. Just be sure to note where they came from. 

Thanks for (anticipating) playing, and for your support. 

The Mare Crisium team