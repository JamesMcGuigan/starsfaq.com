Stars! Overall Planet Habitability and Race Econ Calculator

Original Author: Henk Poell - Additions by: Tiib, M.A, C.R et al

The zip file should be unzipped with the "Use folder names" option selected, 
to preserve the folder structure.

The folder structure is:

Main folder:

habcalc.html
onecol.css
twocol.css

'images' subfolder:

All images

