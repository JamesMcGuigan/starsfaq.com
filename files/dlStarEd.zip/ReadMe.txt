StarEd - An Editor for Stars! 

By Stuart Douglas

Enable word-wrap for best viewing.

Hi, thanks for using my program. I hope everything works fine for you.

Before you dive deep into modifying your Stars! exe file, there are a few things you should know. Please read all of this file as it contains some instructions and pointers.

VERSION 1.2

* German Version 2.7 JCR3 Support

* Grids show Blue cell backgrounds for values lower then the loaded exe, and Yellow cell backgrounds for higher values - makes finding changes easier

* MOD files are now STM files. STM files will now also save the STM/MOD Title, Author and version of StarEd used. Old style MOD files still work just fine in V1.2

* Remaining hull variables now available, they are:
	+ Initiative

	+ Armed?	0 = Unarmed
			1 = Small Armed
			2 = Large Armed
			3 = Bomber
		(I think this will affect battle orders)

	+ Category:	0 = Colony
			1 = Freighter
			2 = Scout
			3 = Warship
			4 = Utility
			5 = Bomber
			6 = Miner
			7 = Fuel Transport
		(Used for filtering enemy designs)

* Unfortunatly, the shape of the shipyard for starbases is hard coded per hull, so the Death Star and Space Dock will always have a circular shipyard.


Future Aims:

* Being able to change the ship/component images. They have been located in the exe and Jeff McBride has sent the Colour Palette used, but I am currently unable to work out how to extract the images with the correct palette. If anyone out there has experiance with this sort of thing, then I would like to hear from you :-)


VERSION 1.1

* Fixed problem were zero values were not allowed by StarEd, when in fact they should have been - if I've still missed some, please let me know.

* Adjusted screen objects slightly so that everything fits nicely at 800x640.

* MOD files now can save a MOD description. StarEd V1.1 will still read in V1.0 MODs, but will save all MODs as V1.1

Cloaking Values:
Enter the following Values for % cloaking
5%	10	30%	60	55%	140	80%	420
10%	20	35%	70	60%	180	85%	540
15%	30	40%	80	65%	220	90%	750
20%	40	45%	90	70%	260	95%	1100
25%	50	50%	100	75%	300



Future Aims:
* Being able to adjust the Initiative for the hulls
* Being able to adjust either a circular or square shipyard.

VERISON 1.0


0. Forgot this when I was writing 6! StarEd works on Stars! versions 2.6 and 2.7 I and J only.

1. Don't modify a Stars exe file you are currently playing games on. You will find your current games do/will not work.

2. Almost everything can be changed apart from special rules for components like MT parts.

3. To modify the ship layouts, double click a slot. The slot will now follow the mouse. Click to confirm the new position. You cannot place slots in the 'crossed' out areas.

4. Even though any ship can be changed to any other type of ship the ship you are changing is still affected by the PRT/LRT options for the race.
i.e. if you change the midgit miner to a nasty death dealing warship, only the races that can use ARM will be able to build this ship.

5. Component and Ship images can be swapped with existing images. In the grid there is an image column. Just replace the value with the value of the component image you want. Ship images are in sets of 4

6. MOD files allow you to save your changes to a small TXT file which you can send to other users of StarEd. They can then load the MOD file to view your modifications and/or save them to any version of stars! A great way for a host to distribute a role play game without sending the bulky modified stars exe to every player.

7. When changing hulls always build new designs of your starting ships, never copy them. If you copy the starting ships, and extra slots tend not to be detected by stars, but are detected if the ship is made by scratch.

8. The editor at the moment only modifies components and hulls. PRTs/LRTs and special rules, etc are not changed.

Even though the program has been tested and includes many limits and bug checks to prevent stars! rejecting the changes, it is still possible that some changes will cause stars! to crash. 

It is quite possible to design a ship hull that has 15 General Purpose slots with 100 components in each slot. But, would you want to? Imagine the cost of building one of these ships (if you don't change the component costs). It would be a great Command ship for a fleet, and would be very difficult to destroy.


Have fun with your new Stars! experiences.

Stuart
