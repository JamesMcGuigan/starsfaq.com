Greetings all,

I have had no time to write any documentation, I hope the interface is obvious enough (I haven't had any problems understanding it :).

Please send bug reports to matd@bigfoot.com.

You can always find the latest version at the Mystery Guild : 
http://www.galaxies.ml.org
(downloads section)

This program provides you with a front end for the Stars! Report files.

Quick Start :

 - Open the file you want to report on in Stars
 - Select report/dump to text file/universe definition
 - Select report/dump to text file/planet information
 - Start SIR
 - Select File/New
 - Fill in the dialog, pointing it to the files you just created
 - press next and fill in race names you know (you don't need to fill all of them)
 - Press OK
 - SIR will ask you for the player numbers of the races you didn't provide, you can find those numbers easely by opening the Score box in Stars!

That's it, SIR will create a map for you and you're started. To add more data use File/Merge.

The rest you'll have to find out on your own until I get a help file ready.

Disclaimer : WARNING
This is a beta version : I do in no way guarantee the proper functioning of this software and shall not be held responsable for any damage done to your system by the use of this software.

Now that's out of the way let me tell you that I have had no serious problems with it.