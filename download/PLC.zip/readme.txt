Inspired by the Stars Calulator written by Mathias Dellaert. 
There was a small inaccuracy bug in the targeting page. While the program was released under the GPL, the program was written in delphi, which I am not familiar with and so wrote a seperate program for my own needs using C++ and Borland C++ Builder 3.0 for the GUI code (which is not GPLed but its what I had available and was familiar with).

Written by James McGuigan - james@starsfaq.com